﻿using System.Reflection;

[assembly: AssemblyTitle("StringToXMLSorted_v4")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("StringToXMLSorted_v4")]
[assembly: AssemblyCopyright("Copyright ©  2022")]
[assembly: AssemblyVersion("1.0.0.*")]

