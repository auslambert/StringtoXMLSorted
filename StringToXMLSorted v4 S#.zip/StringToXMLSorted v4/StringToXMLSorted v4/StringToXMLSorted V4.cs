﻿using System;
using System.Text;
using System.Collections.Generic;
using Crestron.SimplSharp;                          				// For Basic SIMPL# Classes
using Crestron.SimplSharp.CrestronIO;                   //File Ops
using Crestron.SimplSharp.CrestronXml;
using Crestron.SimplSharp.CrestronXmlLinq;              //XML Handling

namespace StringToXMLSorted_v4
{
    public class SortedXmlModule
    {
        //Instantiate The Delegate / Event Handler
        public delegate void ReadCountFromSharp(SimplSharpString Count);
        public delegate void ReadLineFromSharp(SimplSharpString Field1, SimplSharpString Field2, SimplSharpString Field3, SimplSharpString Field4, SimplSharpString Field5);
        public ReadCountFromSharp myReadCountFromSharp { get; set; }
        public ReadLineFromSharp myReadLineFromSharp { get; set; }
        List<LineItem> DataList = new List<LineItem>();
        public LineItem TmpLine;
        private FileStream myStream;
        public string fPath;
        public string XMLFileDescriptor;
        public string Field1Name;
        public string Field2Name;
        public string Field3Name;
        public string Field4Name;
        public string Field5Name;
        public ushort SortOrder;
        public ushort ConsoleLogLevel;

        public struct LineItem
        {
            public string Field1;
            public string Field2;
            public string Field3;
            public string Field4;
            public string Field5;

            public LineItem(string Field1, string Field2, string Field3, string Field4, string Field5)
            {
                this.Field1 = Field1;
                this.Field2 = Field2;
                this.Field3 = Field3;
                this.Field4 = Field4;
                this.Field5 = Field5;
            }
        }


        public void StringToXMLSorted()
        {
        }

        public void Initialize(String pathFromSplus, String XMLDesc, String F1Name, String F2Name, String F3Name, String F4Name, String F5Name, string ConsoleLogLevelString)
        {
            try
            {
                fPath = pathFromSplus;
                ConsoleLogLevel = ushort.Parse(ConsoleLogLevelString);

                //remove any whitespace as Crestron's XML will barf on it
                XMLFileDescriptor = XMLDesc.Replace(" ", String.Empty).Replace("[", "-").Replace("]", "-").Replace("(", "-").Replace(")", "-");

                if (!String.IsNullOrEmpty(F1Name))  Field1Name = F1Name.Replace(" ", String.Empty).Replace("[", "-").Replace("]", "-").Replace("(", "-").Replace(")", "-");
                else Field1Name = null;
                if (!String.IsNullOrEmpty(F2Name))  Field2Name = F2Name.Replace(" ", String.Empty).Replace("[", "-").Replace("]", "-").Replace("(", "-").Replace(")", "-");
                else Field2Name = null;
                if (!String.IsNullOrEmpty(F3Name)) Field3Name = F3Name.Replace(" ", String.Empty).Replace("[", "-").Replace("]", "-").Replace("(", "-").Replace(")", "-");
                else Field3Name = null;
                if (!String.IsNullOrEmpty(F4Name)) Field4Name = F4Name.Replace(" ", String.Empty).Replace("[", "-").Replace("]", "-").Replace("(", "-").Replace(")", "-");
                else Field4Name = null;
                if (!String.IsNullOrEmpty(F5Name)) Field5Name = F5Name.Replace(" ", String.Empty).Replace("[", "-").Replace("]", "-").Replace("(", "-").Replace(")", "-");
                else Field5Name = null;
            }
            catch (Exception e)
            {
                ErrorLog.Error("Exception: {0}", e.Message);
            }
        }

        public void SetSortOrder(ushort SortOrderFromSplus)
        {
            SortOrder = SortOrderFromSplus;
        }

        public void ClearArray()
        {
            try
            {
                DataList.Clear();
            }
            catch (Exception e)
            {
                ErrorLog.Error("Exception: {0}", e.Message);
            }
        }

        public void ReadFile()
        {
            try
            {
                OpenFileAndRead();
                myReadCountFromSharp(new SimplSharpString(DataList.Count.ToString()));
            }
            catch (Exception e)
            {
                ErrorLog.Error("Exception: {0}", e.Message);
            }
        }

        public void ReadLine(ushort LineIndex)
        {
            try
            {
                if (LineIndex < DataList.Count)
                {
                    if (ConsoleLogLevel > 2) CrestronConsole.PrintLine("StringToXml: datalist readout F1:{0},F2:{1},F3:{2},F4:{3},F5:{4}\n", DataList[LineIndex].Field1,
                                                                                                                                              DataList[LineIndex].Field2,
                                                                                                                                              DataList[LineIndex].Field3,
                                                                                                                                              DataList[LineIndex].Field4,
                                                                                                                                              DataList[LineIndex].Field5);                    

                    myReadLineFromSharp(new SimplSharpString(DataList[LineIndex].Field1.ToString()),
                                        new SimplSharpString(DataList[LineIndex].Field2.ToString()),
                                        new SimplSharpString(DataList[LineIndex].Field3.ToString()),
                                        new SimplSharpString(DataList[LineIndex].Field4.ToString()),
                                        new SimplSharpString(DataList[LineIndex].Field5.ToString()));
                    }
                else return;

            }
            catch (Exception e)
            {
                ErrorLog.Error("Exception: {0}", e.Message);
            }
        }

        public void WriteLine(String Field1, string Field2, string Field3, string Field4, string Field5)
        {
            try
            {
                if (ConsoleLogLevel > 2) CrestronConsole.PrintLine("StringToXml: Writing Record F1:{0},F2:{1},F3:{2},F4:{3},F5:{4}\n", Field1,
                                                                                                                                       Field2,
                                                                                                                                       Field3,
                                                                                                                                       Field4,
                                                                                                                                       Field5);
                DataList.Add(new LineItem(Field1, Field2, Field3, Field4, Field5));
            }
            catch (Exception e)
            {
                ErrorLog.Error("Exception: {0}", e.Message);
            }
        }

        public void WriteFile()
        {
            if (DataList.Count < 1)
            {
                if (ConsoleLogLevel > 0) CrestronConsole.PrintLine("StringToXml:Write File {0}: No records to Write\n", Path.GetFileName(fPath));
                return; //nothing to write; exit
            }
            else
            {
                if (ConsoleLogLevel > 0 & SortOrder == 0) CrestronConsole.PrintLine("StringToXml: Write File {0}, No Sorting\n", Path.GetFileName(fPath), Field1Name);
                if (ConsoleLogLevel > 0 & SortOrder == 1) CrestronConsole.PrintLine("StringToXml: Write File {0}, Sort by {1}, Acending\n", Path.GetFileName(fPath), Field1Name);
                if (ConsoleLogLevel > 0 & SortOrder == 2) CrestronConsole.PrintLine("StringToXml: Write File {0}, Sort by {1}, Decending\n", Path.GetFileName(fPath), Field1Name);
            }

            //sort the DataList alphabetically
            try
            {
                switch (SortOrder)
                {
                    case (0):
                        {
                            break;    //do nothing; no sort
                        }
                    case (1):           //sort Ascending
                        {
                            DataList.Sort((a, b) => a.Field1.CompareTo(b.Field1));
                            break;
                        }
                    case (2):           //sort Descending
                        {
                            DataList.Sort((a, b) => b.Field1.CompareTo(a.Field1));
                            break;
                        }
                }
            }
            catch (Exception e)
            {
                ErrorLog.Error("Sort Exception: {0}", e.Message);
            }



            var WriteDoc = new XDocument(
                new XDeclaration("1.0", "utf-8", "yes"),
                new XComment("XML Data Storage"),
                new XComment(DateTime.Now.ToString()));

            //Add the Root Element  
            var rootElement = new XElement(XMLFileDescriptor);
            // Now we will add the records
            var Count = 0;
            foreach (LineItem temp in DataList)
            {
                if (ConsoleLogLevel > 2) CrestronConsole.PrintLine("StringToXml: Writing record in file: {0}\n", Path.GetFileName(fPath));

                //We should have a record with data at this point. If all fields are empty...
                if (String.IsNullOrEmpty(temp.Field1) && 
                    String.IsNullOrEmpty(temp.Field2) &&
                    String.IsNullOrEmpty(temp.Field3) &&
                    String.IsNullOrEmpty(temp.Field4) &&
                    String.IsNullOrEmpty(temp.Field5)) continue; //reject this record and don't write it.

                // Create Record Element
                Count++;
                var RecordElementLabel = "Record" + Count;
                var recElement = new XElement(RecordElementLabel);        //don't need whitespace removal here as we control what the content is.

                //Add the line item Field1 If the FieldName is Defined 
                if (!String.IsNullOrEmpty(Field1Name))
                {
                    var Field1Element = new XElement(Field1Name, temp.Field1);
                    recElement.Add(Field1Element);
                }

                //Add the line item Field2 If the FieldName is Defined 
                if (!String.IsNullOrEmpty(Field2Name))
                {
                    var Field2Element = new XElement(Field2Name, temp.Field2);
                    recElement.Add(Field2Element);
                }
                //Add the line item Field3 If the FieldName is Defined 
                if (!String.IsNullOrEmpty(Field3Name))
                {
                    var Field3Element = new XElement(Field3Name, temp.Field3);
                    recElement.Add(Field3Element);
                }
                //Add the line item Field4 If the FieldName is Defined 
                if (!String.IsNullOrEmpty(Field4Name))
                {
                    var Field4Element = new XElement(Field4Name, temp.Field4);
                    recElement.Add(Field4Element);
                }
                //Add the line item Field5 If the FieldName is Defined 
                if (!String.IsNullOrEmpty(Field5Name))
                {
                    var Field5Element = new XElement(Field5Name, temp.Field5);
                    recElement.Add(Field5Element);
                }

                // add the Record element to root  
                rootElement.Add(recElement);
            }

            //write the file
            WriteDoc.Add(rootElement);
            using (var fs = new FileStream(fPath, FileMode.Create, FileAccess.Write))
            {
                using (var xw = new XmlWriter(fs))
                {
                    WriteDoc.Save(xw);
                    //fs.Close();
                }
                fs.Close();
            }

        }

        public bool OpenFileAndRead()
        {
            bool returnvalue = true;
            try
            {
                myStream = new FileStream(fPath, FileMode.Open, FileAccess.Read, FileShare.Read);
            }
            catch (FileNotFoundException e)
            {
                ErrorLog.Error("StringToXmlSorted v4, {0} File Not Found Exception: {1}", Path.GetFileName(fPath), e.Message);
                if (ConsoleLogLevel > 0) CrestronConsole.PrintLine("StringToXmlSorted v4, {0} File Not Found Exception: {1}", Path.GetFileName(fPath), e.Message);
                return false;
            }
            catch (DirectoryNotFoundException e)
            {
                ErrorLog.Error("StringToXmlSorted v4, {0} Directory Not Found Exception: {1}", Path.GetFileName(fPath), e.Message);
                if (ConsoleLogLevel > 0) CrestronConsole.PrintLine("StringToXmlSorted v4, {0} Directory Not Found Exception: {1}", Path.GetFileName(fPath), e.Message);
                return false;
            }
            catch (PathTooLongException e)
            {
                ErrorLog.Error("StringToXmlSorted v4, {0} Path Too Long Exception: {1}", Path.GetFileName(fPath), e.Message);
                if (ConsoleLogLevel > 0) CrestronConsole.PrintLine("StringToXmlSorted v4, {0} Path Too Long Exception: {1}", Path.GetFileName(fPath), e.Message);
                return false;
            }
            catch (Exception e)
            {
                ErrorLog.Error("Exception: {0}", e.Message);
                if (ConsoleLogLevel > 0) CrestronConsole.PrintLine("Exception: {0}", e.Message);
                return false;
            }
            try
            {
                //clear the list so we can write it from scratch
                DataList.Clear();

                XmlDocument ReadDoc = new XmlDocument();
                ReadDoc.Load(myStream);

                //pull the records
                foreach (XmlNode Record in ReadDoc.DocumentElement.ChildNodes)
                {
                    try
                    {
                        //clear the Tmpline array ready for this record.

                        TmpLine.Field1 = string.Empty;
                        TmpLine.Field2 = string.Empty;
                        TmpLine.Field3 = string.Empty;
                        TmpLine.Field4 = string.Empty;
                        TmpLine.Field5 = string.Empty;


                        //loop through the children of the record
                        try
                        {
                            foreach (XmlNode SubNode in Record)
                            {
                                if ((SubNode.Name) == Field1Name) TmpLine.Field1 = SubNode.InnerText;
                                if ((SubNode.Name) == Field2Name) TmpLine.Field2 = SubNode.InnerText;
                                if ((SubNode.Name) == Field3Name) TmpLine.Field3 = SubNode.InnerText;
                                if ((SubNode.Name) == Field4Name) TmpLine.Field4 = SubNode.InnerText;
                                if ((SubNode.Name) == Field5Name) TmpLine.Field5 = SubNode.InnerText;

                                if (ConsoleLogLevel > 2)
                                {
                                    CrestronConsole.PrintLine("StringToXml,Subnode OuterXml {0}\n", SubNode.OuterXml);
                                    CrestronConsole.PrintLine("StringToXml: TmpLine Fields F1:{0},F2:{1},F3:{2},F4:{3},F5:{4}\n", TmpLine.Field1,
                                                                                                                                  TmpLine.Field2,
                                                                                                                                  TmpLine.Field3,
                                                                                                                                  TmpLine.Field4,
                                                                                                                                  TmpLine.Field5);
                                }
                            }
                            //after populating the TmpLine with the record, write it to list.
                            DataList.Add(TmpLine);
                        }
                        catch (Exception e)
                        {
                            ErrorLog.Error("StringToXmlSorted v4, Subnode read loop Exception: {0}", e.Message);
                            if (ConsoleLogLevel > 0) CrestronConsole.PrintLine("StringToXmlSorted v4, Subnode read loop Exception: {0}", e.Message);
                            return false;

                        }
                    }
                    catch (Exception e)
                    {
                        ErrorLog.Error("StringToXmlSorted v4, individual record read loop Exception: {0}", e.Message);
                        if (ConsoleLogLevel > 0) CrestronConsole.PrintLine("StringToXmlSorted v4, individual record read loop Exception: {0}", e.Message);
                        return false;

                    }
                }
            }
            catch (Exception e)
            {
                ErrorLog.Error("Exception: {0}", e.Message);
                myStream.Close();
                return false;
            }
            finally
            {
                myStream.Close();
            }

            int Count = 1;
            if (ConsoleLogLevel > 1)
            {
                if (ConsoleLogLevel > 1) CrestronConsole.PrintLine("StringToXml: Reading {0}:\n", Path.GetFileName(fPath));
                foreach (LineItem temp in DataList)
                {
                    CrestronConsole.PrintLine("StringToXml:    Record {0}:\n", Count);
                    if (!String.IsNullOrEmpty(Field1Name)) CrestronConsole.PrintLine("StringToXml:        {0}: {1}\n",Field1Name, temp.Field1);
                    if (!String.IsNullOrEmpty(Field2Name)) CrestronConsole.PrintLine("StringToXml:        {0}: {1}\n", Field2Name, temp.Field2);
                    if (!String.IsNullOrEmpty(Field3Name)) CrestronConsole.PrintLine("StringToXml:        {0}: {1}\n", Field3Name, temp.Field3);
                    if (!String.IsNullOrEmpty(Field4Name)) CrestronConsole.PrintLine("StringToXml:        {0}: {1}\n", Field4Name, temp.Field4);
                    if (!String.IsNullOrEmpty(Field5Name)) CrestronConsole.PrintLine("StringToXml:        {0}: {1}\n", Field5Name, temp.Field5);
                    Count++;
                }
            }
            if (ConsoleLogLevel > 0) CrestronConsole.PrintLine("StringToXml: Reading {0}: Read complete. Num records in list:{1}\n", Path.GetFileName(fPath), DataList.Count);
            return returnvalue;
        }
    }
}
