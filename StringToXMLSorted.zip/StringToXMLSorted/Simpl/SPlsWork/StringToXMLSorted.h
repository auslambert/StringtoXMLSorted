namespace StringToXMLSorted;
        // class declarations
         class SortedXmlModule;
     class SortedXmlModule 
    {
        // class delegates
        delegate FUNCTION ReadLineFromSharp ( SIMPLSHARPSTRING Description , SIMPLSHARPSTRING Data );

        // class events

        // class functions
        FUNCTION StringToXMLSorted ();
        FUNCTION Initialize ( STRING pathFromSplus , STRING XMLDesc );
        FUNCTION SetSortOrder ( INTEGER SortOrderFromSplus );
        FUNCTION ClearArray ();
        FUNCTION ReadFile ();
        FUNCTION ReadLine ( INTEGER LineIndex );
        FUNCTION WriteLine ( STRING Description , STRING Data );
        FUNCTION WriteFile ();
        STRING_FUNCTION ToString ();
        SIGNED_LONG_INTEGER_FUNCTION GetHashCode ();

        // class variables
        STRING fPath[];
        STRING XMLFileDescriptor[];
        INTEGER SortOrder;

        // class properties
        DelegateProperty ReadLineFromSharp myReadLineFromSharp;
    };

