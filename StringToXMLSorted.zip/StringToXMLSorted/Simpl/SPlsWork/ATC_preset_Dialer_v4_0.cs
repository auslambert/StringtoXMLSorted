using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Linq;
using Crestron;
using Crestron.Logos.SplusLibrary;
using Crestron.Logos.SplusObjects;
using Crestron.SimplSharp;

namespace UserModule_ATC_PRESET_DIALER_V4_0
{
    public class UserModuleClass_ATC_PRESET_DIALER_V4_0 : SplusObject
    {
        static CCriticalSection g_criticalSection = new CCriticalSection();
        
        
        
        
        Crestron.Logos.SplusObjects.StringInput NUMBERTODIAL;
        Crestron.Logos.SplusObjects.DigitalOutput KEY0;
        Crestron.Logos.SplusObjects.DigitalOutput KEY1;
        Crestron.Logos.SplusObjects.DigitalOutput KEY2;
        Crestron.Logos.SplusObjects.DigitalOutput KEY3;
        Crestron.Logos.SplusObjects.DigitalOutput KEY4;
        Crestron.Logos.SplusObjects.DigitalOutput KEY5;
        Crestron.Logos.SplusObjects.DigitalOutput KEY6;
        Crestron.Logos.SplusObjects.DigitalOutput KEY7;
        Crestron.Logos.SplusObjects.DigitalOutput KEY8;
        Crestron.Logos.SplusObjects.DigitalOutput KEY9;
        Crestron.Logos.SplusObjects.DigitalOutput KEYSTAR;
        Crestron.Logos.SplusObjects.DigitalOutput KEYHASH;
        Crestron.Logos.SplusObjects.DigitalOutput PREDIAL_CLEAR;
        Crestron.Logos.SplusObjects.DigitalOutput DIAL;
        UShortParameter PULSEWIDTH;
        UShortParameter PULSEINTERVAL;
        ushort I = 0;
        object NUMBERTODIAL_OnChange_0 ( Object __EventInfo__ )
        
            { 
            Crestron.Logos.SplusObjects.SignalEventArgs __SignalEventArg__ = (Crestron.Logos.SplusObjects.SignalEventArgs)__EventInfo__;
            try
            {
                SplusExecutionContext __context__ = SplusThreadStartCode(__SignalEventArg__);
                ushort POS = 0;
                ushort STRLENGTH = 0;
                ushort IDIGIT = 0;
                ushort DIGITDIALEDFLAG = 0;
                
                CrestronString SDIGIT;
                SDIGIT  = new CrestronString( Crestron.Logos.SplusObjects.CrestronStringEncoding.eEncodingASCII, 1, this );
                
                
                __context__.SourceCodeLine = 59;
                STRLENGTH = (ushort) ( Functions.Length( NUMBERTODIAL ) ) ; 
                __context__.SourceCodeLine = 60;
                POS = (ushort) ( 1 ) ; 
                __context__.SourceCodeLine = 61;
                DIGITDIALEDFLAG = (ushort) ( 0 ) ; 
                __context__.SourceCodeLine = 63;
                Functions.Pulse ( PULSEWIDTH  .Value, PREDIAL_CLEAR ) ; 
                __context__.SourceCodeLine = 64;
                Functions.Delay (  (int) ( PULSEINTERVAL  .Value ) ) ; 
                __context__.SourceCodeLine = 66;
                while ( Functions.TestForTrue  ( ( Functions.BoolToInt ( (Functions.TestForTrue ( Functions.BoolToInt ( POS > 0 ) ) && Functions.TestForTrue ( Functions.BoolToInt ( POS <= STRLENGTH ) )) ))  ) ) 
                    { 
                    __context__.SourceCodeLine = 68;
                    SDIGIT  .UpdateValue ( Functions.Mid ( NUMBERTODIAL ,  (int) ( POS ) ,  (int) ( 1 ) )  ) ; 
                    __context__.SourceCodeLine = 71;
                    if ( Functions.TestForTrue  ( ( Functions.BoolToInt (SDIGIT == "#"))  ) ) 
                        { 
                        __context__.SourceCodeLine = 73;
                        Functions.Pulse ( PULSEWIDTH  .Value, KEYHASH ) ; 
                        __context__.SourceCodeLine = 74;
                        DIGITDIALEDFLAG = (ushort) ( 1 ) ; 
                        } 
                    
                    else 
                        {
                        __context__.SourceCodeLine = 76;
                        if ( Functions.TestForTrue  ( ( Functions.BoolToInt (SDIGIT == "*"))  ) ) 
                            { 
                            __context__.SourceCodeLine = 78;
                            Functions.Pulse ( PULSEWIDTH  .Value, KEYSTAR ) ; 
                            __context__.SourceCodeLine = 79;
                            DIGITDIALEDFLAG = (ushort) ( 1 ) ; 
                            } 
                        
                        else 
                            {
                            __context__.SourceCodeLine = 81;
                            if ( Functions.TestForTrue  ( ( Functions.BoolToInt (SDIGIT == "0"))  ) ) 
                                { 
                                __context__.SourceCodeLine = 83;
                                Functions.Pulse ( PULSEWIDTH  .Value, KEY0 ) ; 
                                __context__.SourceCodeLine = 84;
                                DIGITDIALEDFLAG = (ushort) ( 1 ) ; 
                                } 
                            
                            else 
                                { 
                                __context__.SourceCodeLine = 88;
                                IDIGIT = (ushort) ( Functions.Atoi( SDIGIT ) ) ; 
                                __context__.SourceCodeLine = 89;
                                if ( Functions.TestForTrue  ( ( Functions.BoolToInt ( IDIGIT > 0 ))  ) ) 
                                    {
                                    __context__.SourceCodeLine = 89;
                                    DIGITDIALEDFLAG = (ushort) ( 1 ) ; 
                                    }
                                
                                __context__.SourceCodeLine = 90;
                                
                                    {
                                    int __SPLS_TMPVAR__SWTCH_1__ = ((int)IDIGIT);
                                    
                                        { 
                                        if  ( Functions.TestForTrue  (  ( __SPLS_TMPVAR__SWTCH_1__ == ( 1) ) ) ) 
                                            {
                                            __context__.SourceCodeLine = 92;
                                            Functions.Pulse ( PULSEWIDTH  .Value, KEY1 ) ; 
                                            }
                                        
                                        else if  ( Functions.TestForTrue  (  ( __SPLS_TMPVAR__SWTCH_1__ == ( 2) ) ) ) 
                                            {
                                            __context__.SourceCodeLine = 93;
                                            Functions.Pulse ( PULSEWIDTH  .Value, KEY2 ) ; 
                                            }
                                        
                                        else if  ( Functions.TestForTrue  (  ( __SPLS_TMPVAR__SWTCH_1__ == ( 3) ) ) ) 
                                            {
                                            __context__.SourceCodeLine = 94;
                                            Functions.Pulse ( PULSEWIDTH  .Value, KEY3 ) ; 
                                            }
                                        
                                        else if  ( Functions.TestForTrue  (  ( __SPLS_TMPVAR__SWTCH_1__ == ( 4) ) ) ) 
                                            {
                                            __context__.SourceCodeLine = 95;
                                            Functions.Pulse ( PULSEWIDTH  .Value, KEY4 ) ; 
                                            }
                                        
                                        else if  ( Functions.TestForTrue  (  ( __SPLS_TMPVAR__SWTCH_1__ == ( 5) ) ) ) 
                                            {
                                            __context__.SourceCodeLine = 96;
                                            Functions.Pulse ( PULSEWIDTH  .Value, KEY5 ) ; 
                                            }
                                        
                                        else if  ( Functions.TestForTrue  (  ( __SPLS_TMPVAR__SWTCH_1__ == ( 6) ) ) ) 
                                            {
                                            __context__.SourceCodeLine = 97;
                                            Functions.Pulse ( PULSEWIDTH  .Value, KEY6 ) ; 
                                            }
                                        
                                        else if  ( Functions.TestForTrue  (  ( __SPLS_TMPVAR__SWTCH_1__ == ( 7) ) ) ) 
                                            {
                                            __context__.SourceCodeLine = 98;
                                            Functions.Pulse ( PULSEWIDTH  .Value, KEY7 ) ; 
                                            }
                                        
                                        else if  ( Functions.TestForTrue  (  ( __SPLS_TMPVAR__SWTCH_1__ == ( 8) ) ) ) 
                                            {
                                            __context__.SourceCodeLine = 99;
                                            Functions.Pulse ( PULSEWIDTH  .Value, KEY8 ) ; 
                                            }
                                        
                                        else if  ( Functions.TestForTrue  (  ( __SPLS_TMPVAR__SWTCH_1__ == ( 9) ) ) ) 
                                            {
                                            __context__.SourceCodeLine = 100;
                                            Functions.Pulse ( PULSEWIDTH  .Value, KEY9 ) ; 
                                            }
                                        
                                        } 
                                        
                                    }
                                    
                                
                                } 
                            
                            }
                        
                        }
                    
                    __context__.SourceCodeLine = 103;
                    POS = (ushort) ( (POS + 1) ) ; 
                    __context__.SourceCodeLine = 104;
                    Functions.Delay (  (int) ( PULSEINTERVAL  .Value ) ) ; 
                    __context__.SourceCodeLine = 66;
                    } 
                
                __context__.SourceCodeLine = 106;
                if ( Functions.TestForTrue  ( ( DIGITDIALEDFLAG)  ) ) 
                    {
                    __context__.SourceCodeLine = 106;
                    Functions.Pulse ( PULSEWIDTH  .Value, DIAL ) ; 
                    }
                
                
                
            }
            catch(Exception e) { ObjectCatchHandler(e); }
            finally { ObjectFinallyHandler( __SignalEventArg__ ); }
            return this;
            
        }
        
    public override object FunctionMain (  object __obj__ ) 
        { 
        try
        {
            SplusExecutionContext __context__ = SplusFunctionMainStartCode();
            
            __context__.SourceCodeLine = 111;
            WaitForInitializationComplete ( ) ; 
            
            
        }
        catch(Exception e) { ObjectCatchHandler(e); }
        finally { ObjectFinallyHandler(); }
        return __obj__;
        }
        
    
    public override void LogosSplusInitialize()
    {
        _SplusNVRAM = new SplusNVRAM( this );
        
        KEY0 = new Crestron.Logos.SplusObjects.DigitalOutput( KEY0__DigitalOutput__, this );
        m_DigitalOutputList.Add( KEY0__DigitalOutput__, KEY0 );
        
        KEY1 = new Crestron.Logos.SplusObjects.DigitalOutput( KEY1__DigitalOutput__, this );
        m_DigitalOutputList.Add( KEY1__DigitalOutput__, KEY1 );
        
        KEY2 = new Crestron.Logos.SplusObjects.DigitalOutput( KEY2__DigitalOutput__, this );
        m_DigitalOutputList.Add( KEY2__DigitalOutput__, KEY2 );
        
        KEY3 = new Crestron.Logos.SplusObjects.DigitalOutput( KEY3__DigitalOutput__, this );
        m_DigitalOutputList.Add( KEY3__DigitalOutput__, KEY3 );
        
        KEY4 = new Crestron.Logos.SplusObjects.DigitalOutput( KEY4__DigitalOutput__, this );
        m_DigitalOutputList.Add( KEY4__DigitalOutput__, KEY4 );
        
        KEY5 = new Crestron.Logos.SplusObjects.DigitalOutput( KEY5__DigitalOutput__, this );
        m_DigitalOutputList.Add( KEY5__DigitalOutput__, KEY5 );
        
        KEY6 = new Crestron.Logos.SplusObjects.DigitalOutput( KEY6__DigitalOutput__, this );
        m_DigitalOutputList.Add( KEY6__DigitalOutput__, KEY6 );
        
        KEY7 = new Crestron.Logos.SplusObjects.DigitalOutput( KEY7__DigitalOutput__, this );
        m_DigitalOutputList.Add( KEY7__DigitalOutput__, KEY7 );
        
        KEY8 = new Crestron.Logos.SplusObjects.DigitalOutput( KEY8__DigitalOutput__, this );
        m_DigitalOutputList.Add( KEY8__DigitalOutput__, KEY8 );
        
        KEY9 = new Crestron.Logos.SplusObjects.DigitalOutput( KEY9__DigitalOutput__, this );
        m_DigitalOutputList.Add( KEY9__DigitalOutput__, KEY9 );
        
        KEYSTAR = new Crestron.Logos.SplusObjects.DigitalOutput( KEYSTAR__DigitalOutput__, this );
        m_DigitalOutputList.Add( KEYSTAR__DigitalOutput__, KEYSTAR );
        
        KEYHASH = new Crestron.Logos.SplusObjects.DigitalOutput( KEYHASH__DigitalOutput__, this );
        m_DigitalOutputList.Add( KEYHASH__DigitalOutput__, KEYHASH );
        
        PREDIAL_CLEAR = new Crestron.Logos.SplusObjects.DigitalOutput( PREDIAL_CLEAR__DigitalOutput__, this );
        m_DigitalOutputList.Add( PREDIAL_CLEAR__DigitalOutput__, PREDIAL_CLEAR );
        
        DIAL = new Crestron.Logos.SplusObjects.DigitalOutput( DIAL__DigitalOutput__, this );
        m_DigitalOutputList.Add( DIAL__DigitalOutput__, DIAL );
        
        NUMBERTODIAL = new Crestron.Logos.SplusObjects.StringInput( NUMBERTODIAL__AnalogSerialInput__, 42, this );
        m_StringInputList.Add( NUMBERTODIAL__AnalogSerialInput__, NUMBERTODIAL );
        
        PULSEWIDTH = new UShortParameter( PULSEWIDTH__Parameter__, this );
        m_ParameterList.Add( PULSEWIDTH__Parameter__, PULSEWIDTH );
        
        PULSEINTERVAL = new UShortParameter( PULSEINTERVAL__Parameter__, this );
        m_ParameterList.Add( PULSEINTERVAL__Parameter__, PULSEINTERVAL );
        
        
        NUMBERTODIAL.OnSerialChange.Add( new InputChangeHandlerWrapper( NUMBERTODIAL_OnChange_0, false ) );
        
        _SplusNVRAM.PopulateCustomAttributeList( true );
        
        NVRAM = _SplusNVRAM;
        
    }
    
    public override void LogosSimplSharpInitialize()
    {
        
        
    }
    
    public UserModuleClass_ATC_PRESET_DIALER_V4_0 ( string InstanceName, string ReferenceID, Crestron.Logos.SplusObjects.CrestronStringEncoding nEncodingType ) : base( InstanceName, ReferenceID, nEncodingType ) {}
    
    
    
    
    const uint NUMBERTODIAL__AnalogSerialInput__ = 0;
    const uint KEY0__DigitalOutput__ = 0;
    const uint KEY1__DigitalOutput__ = 1;
    const uint KEY2__DigitalOutput__ = 2;
    const uint KEY3__DigitalOutput__ = 3;
    const uint KEY4__DigitalOutput__ = 4;
    const uint KEY5__DigitalOutput__ = 5;
    const uint KEY6__DigitalOutput__ = 6;
    const uint KEY7__DigitalOutput__ = 7;
    const uint KEY8__DigitalOutput__ = 8;
    const uint KEY9__DigitalOutput__ = 9;
    const uint KEYSTAR__DigitalOutput__ = 10;
    const uint KEYHASH__DigitalOutput__ = 11;
    const uint PREDIAL_CLEAR__DigitalOutput__ = 12;
    const uint DIAL__DigitalOutput__ = 13;
    const uint PULSEWIDTH__Parameter__ = 10;
    const uint PULSEINTERVAL__Parameter__ = 11;
    
    [SplusStructAttribute(-1, true, false)]
    public class SplusNVRAM : SplusStructureBase
    {
    
        public SplusNVRAM( SplusObject __caller__ ) : base( __caller__ ) {}
        
        
    }
    
    SplusNVRAM _SplusNVRAM = null;
    
    public class __CEvent__ : CEvent
    {
        public __CEvent__() {}
        public void Close() { base.Close(); }
        public int Reset() { return base.Reset() ? 1 : 0; }
        public int Set() { return base.Set() ? 1 : 0; }
        public int Wait( int timeOutInMs ) { return base.Wait( timeOutInMs ) ? 1 : 0; }
    }
    public class __CMutex__ : CMutex
    {
        public __CMutex__() {}
        public void Close() { base.Close(); }
        public void ReleaseMutex() { base.ReleaseMutex(); }
        public int WaitForMutex() { return base.WaitForMutex() ? 1 : 0; }
    }
     public int IsNull( object obj ){ return (obj == null) ? 1 : 0; }
}


}
