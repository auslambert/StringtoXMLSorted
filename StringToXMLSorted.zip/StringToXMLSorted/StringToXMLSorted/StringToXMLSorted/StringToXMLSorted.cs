﻿using System;
using System.Text;
using System.Collections.Generic;
using Crestron.SimplSharp;                          				// For Basic SIMPL# Classes
using Crestron.SimplSharp.CrestronIO;                   //File Ops
using Crestron.SimplSharp.CrestronXml;
using Crestron.SimplSharp.CrestronXmlLinq;              //XML Handling

namespace StringToXMLSorted
{
    public class SortedXmlModule
    {
        //Instantiate The Delegate / Event Handler
        public delegate void ReadLineFromSharp(SimplSharpString Description, SimplSharpString Data);
        public ReadLineFromSharp myReadLineFromSharp { get; set; }
        List<LineItem> DataList = new List<LineItem>();
        public LineItem TmpLine;
        private FileStream myStream;
        public string fPath;
        public string XMLFileDescriptor;
        public ushort SortOrder;

        public struct LineItem
        {
            public string Description;
            public string Data;

            public LineItem(string Description,string Data)
            {
                this.Description = Description;
                this.Data = Data;
            }
        }

        
        public void StringToXMLSorted()
        {
        }

        public void Initialize(String pathFromSplus, String XMLDesc)
        {
            try
            {
                fPath = pathFromSplus;
                XMLFileDescriptor = XMLDesc;
            }
            catch (Exception e)
            {
                ErrorLog.Error("Exception: {0}", e.Message);
            }
        }

        public void SetSortOrder(ushort SortOrderFromSplus)
        {
            SortOrder = SortOrderFromSplus;
        }

        public void ClearArray()
        {
            try
            {
                DataList.Clear();
            }
            catch (Exception e)
            {
                ErrorLog.Error("Exception: {0}", e.Message);
            }
        }

        public void ReadFile()
        {
            try
            {
                OpenFileAndRead();
            }
            catch (Exception e)
            {
                ErrorLog.Error("Exception: {0}", e.Message);
            }
        }

        public void ReadLine(ushort LineIndex)
        {
            try
            {
                if (LineIndex <= DataList.Count)
                {
                    myReadLineFromSharp(new SimplSharpString(DataList[LineIndex].Description.ToString()), new SimplSharpString(DataList[LineIndex].Data.ToString()));
                    CrestronConsole.PrintLine("ReadLine: Desc |{0)| Data |{1}|\n", DataList[LineIndex].Description.ToString(), DataList[LineIndex].Data.ToString());
                }
                else return;

            }
            catch (Exception e)
            {
                ErrorLog.Error("Exception: {0}", e.Message);
            }
        }

        public void WriteLine(String Description, string Data)
        {
            try
            {
                DataList.Add(new LineItem(Description,Data));
            }
            catch (Exception e)
            {
                ErrorLog.Error("Exception: {0}", e.Message);
            }
        }

        public void WriteFile()
        {
            //sort the DataList alphabetically
            try
            {
                switch (SortOrder)
                {
                    case (0):
                        {
                            break;    //do nothing; no sort
                        }
                    case (1):           //sort Ascending
                        {
                            DataList.Sort((a, b) => a.Description.CompareTo(b.Description));
                            break;
                        }
                    case (2):           //sort Descending
                        {
                            DataList.Sort((a, b) => b.Description.CompareTo(a.Description));
                            break;
                        }
                }
            }
            catch (Exception e)
            {
                ErrorLog.Error("Sort Exception: {0}", e.Message);
            }
            

            CrestronConsole.PrintLine("WriteFile: Sorted; Order by: {0}\n",SortOrder);

            var WriteDoc = new XDocument(
                new XDeclaration("1.0", "utf-8", "yes"),
                new XComment("XML Data Storage"),
                new XComment(DateTime.Now.ToString()));
           
            //Add the Root Element  
            var rootElement = new XElement(XMLFileDescriptor.Replace(" ", String.Empty));   //remove any whitespace as XML will barf on it
            // Now we will add the records  
            foreach (LineItem temp in DataList)
            {
                //We should have a record pair with data at this point.
                if (String.IsNullOrEmpty(temp.Description) && String.IsNullOrEmpty(temp.Data)) continue; //reject this record and don't write it.

                // Create RecordPair Element  
                var recElement = new XElement("RecordPair");        //don't need whitespace removal here as we control what the content is.
                    //Add the line item description
                    var descElement = new XElement("Description", temp.Description);
                    recElement.Add(descElement);

                    //Add the line item Data 
                    var dataElement = new XElement("Data", temp.Data);
                    recElement.Add(dataElement);
                // add the Recordpair element to root  
                rootElement.Add(recElement);
            }

            //write the file
            WriteDoc.Add(rootElement);
            using (var fs = new FileStream(fPath, FileMode.Create, FileAccess.Write))
            {
                using (var xw = new XmlWriter(fs))
                {
                    WriteDoc.Save(xw);
                }
            }

        }

        public bool OpenFileAndRead()
        {
            bool returnvalue = true;
            try
            {
                myStream = new FileStream(fPath, FileMode.Open);
            }
            catch (FileNotFoundException e)
            {
                ErrorLog.Error("File Not Found Exception: {0}", e.Message);
                CrestronConsole.PrintLine("File Not Found Exception: {0}", e.Message);
                return false;
            }
            catch (DirectoryNotFoundException e)
            {
                ErrorLog.Error("Directory Not Found Exception: {0}", e.Message);
                CrestronConsole.PrintLine("Directory Not Found Exception: {0}", e.Message);
                return false;
            }
            catch (PathTooLongException e)
            {
                ErrorLog.Error("Path Too Long Exception: {0}", e.Message);
                CrestronConsole.PrintLine("Path Too Long Exception: {0}", e.Message);
                return false;
            }
            catch (Exception e)
            {
                ErrorLog.Error("Exception: {0}", e.Message);
                CrestronConsole.PrintLine("Exception: {0}", e.Message);
                return false;
            }            
            try
            {
                //clear the list so we can write it from scratch
                DataList.Clear();

                XmlDocument ReadDoc = new XmlDocument();
                ReadDoc.Load(myStream);

                //pull the record pairs
                foreach (XmlNode Record in ReadDoc.DocumentElement.ChildNodes)
                {
                    //loop through the children of the recordPair
                    foreach (XmlNode SubNode in Record)
                    {
                        switch (SubNode.Name)
                        {
                            case "Description":
                                {
                                    TmpLine.Description = SubNode.InnerText;
                                    break;
                                }
                            case "Data":
                                {
                                    TmpLine.Data = SubNode.InnerText;
                                    break;
                                }
                        }
                    }
                    //after populating the TmpLine with the record, write it to file.
                    DataList.Add(TmpLine);
                }
            }
            catch (Exception e)
            {
                ErrorLog.Error("Exception: {0}", e.Message);
                return false;
            }
            finally
            {
                myStream.Close();
            }

            foreach (LineItem temp in DataList)
            {
                CrestronConsole.PrintLine("OpenFileForReading: Record: Desc: {0} Data: {1}\n", temp.Description, temp.Data);
            }
            CrestronConsole.PrintLine("OpenFileForReading: Read complete. Num records in list:{0}\n", DataList.Count);
            return returnvalue;
        }
    }
}
