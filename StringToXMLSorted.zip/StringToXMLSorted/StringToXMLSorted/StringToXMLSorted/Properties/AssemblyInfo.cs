﻿using System.Reflection;

[assembly: AssemblyTitle("StringToXMLSorted")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("StringToXMLSorted")]
[assembly: AssemblyCopyright("Copyright ©  2019")]
[assembly: AssemblyVersion("1.0.0.*")]

